"""Memory-conscious RQ1 analysis of Dingdong-Inc/FreshRetailNet-50K.

Definition: 1 = stockout; use 06:00-21:59, 16 hours per observed day.
Episodes reset at the daily operating boundary; recurrence uses consecutive
calendar days, not merely the next observed row.
"""
from pathlib import Path
import csv
import math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import pyarrow as pa
import pyarrow.parquet as pq
import duckdb
from datasets import load_dataset

OUT = Path('results'); OUT.mkdir(exist_ok=True)
TEMP = OUT / 'daily_compact.parquet'
BATCH = 25000
SCHEMA = pa.schema([
    ('store_id', pa.int64()), ('product_id', pa.int64()),
    ('dt', pa.string()), ('mask', pa.uint16()),
    ('hours', pa.uint8()), ('episodes', pa.uint8()),
    ('longest', pa.uint8()), ('first_category_id', pa.int64())
])

def transform(rows):
    result = {name: [] for name in SCHEMA.names}
    for r in rows:
        values = r['hours_stock_status']
        if values is None or len(values) != 24:
            raise ValueError('Expected exactly 24 hourly status values')
        day = values[6:22]
        if any(x not in (0, 1) for x in day):
            raise ValueError('Unexpected stock-status value')
        mask = 0; episodes = 0; run = 0; longest = 0; prev = 0
        for i, v in enumerate(day):
            if v == 1:
                mask |= (1 << i)
                if not prev: episodes += 1
                run += 1; longest = max(longest, run)
            else: run = 0
            prev = v
        expected = r.get('stock_hour6_22_cnt')
        if expected is not None and int(expected) != mask.bit_count():
            raise ValueError('Stockout count disagrees with source reference column')
        result['store_id'].append(int(r['store_id']))
        result['product_id'].append(int(r['product_id']))
        result['dt'].append(str(r['dt'])[:10])
        result['mask'].append(mask)
        result['hours'].append(mask.bit_count())
        result['episodes'].append(episodes)
        result['longest'].append(longest)
        result['first_category_id'].append(int(r.get('first_category_id') or -1))
    return pa.Table.from_pydict(result, schema=SCHEMA)

def ingest():
    print('Streaming source dataset; this may take a while... ', flush=True)
    dataset = load_dataset('Dingdong-Inc/FreshRetailNet-50K', split='train', streaming=True)
    writer = pq.ParquetWriter(TEMP, SCHEMA, compression='zstd')
    rows = []; count = 0
    try:
        for row in dataset:
            rows.append(row)
            if len(rows) >= BATCH:
                writer.write_table(transform(rows)); count += len(rows); rows.clear()
                if count % 250000 == 0: print(f'Processed {count:,} rows', flush=True)
        if rows: writer.write_table(transform(rows)); count += len(rows)
    finally: writer.close()
    print(f'Finished ingestion: {count:,} rows')

def summarize():
    conn = duckdb.connect(database=str(OUT / 'rq1.duckdb'))
    conn.execute("SET memory_limit='1GB'")
    conn.execute("SET threads=2")
    conn.execute("SET temp_directory='results/duckdb_tmp'")
    path = str(TEMP).replace("'", "''")
    query = f"""SELECT store_id, product_id, dt, mask, hours, episodes, longest,
                      first_category_id
               FROM read_parquet('{path}')
               ORDER BY store_id, product_id, dt"""
    reader = conn.execute(query).fetch_record_batch(rows_per_batch=20000)
    summary = []
    store = {}; category = {}; hourly = np.zeros(16, dtype=np.int64)
    current = None; acc = None; previous_day = None; previous_out = False
    duplicate = 0; total_rows = 0

    def flush():
        if acc is None: return
        observed = acc['observed_days']
        summary.append({
            'store_id': current[0], 'product_id': current[1],
            'observed_days': observed,
            'stockout_days': acc['stockout_days'],
            'frequency': acc['stockout_days'] / observed,
            'total_stockout_hours': acc['total_hours'],
            'stockout_hour_rate': acc['total_hours'] / (16 * observed),
            'episode_count': acc['episodes'],
            'avg_episode_duration_hours': acc['total_hours'] / acc['episodes'] if acc['episodes'] else np.nan,
            'max_daily_episode_hours': acc['longest'],
            'eligible_repeat_days': acc['repeat_base'],
            'repeat_days': acc['repeat_events'],
            'recurrence': acc['repeat_events'] / acc['repeat_base'] if acc['repeat_base'] else np.nan
        })

    for batch in reader:
        d = batch.to_pydict()
        for i in range(batch.num_rows):
            total_rows += 1
            key = (d['store_id'][i], d['product_id'][i]); day = pd.Timestamp(d['dt'][i])
            mask = d['mask'][i]; hours = d['hours'][i]; any_so = hours > 0
            if key != current:
                flush(); current = key; previous_day = None; previous_out = False
                acc = dict(observed_days=0, stockout_days=0, total_hours=0,
                           episodes=0, longest=0, repeat_base=0, repeat_events=0)
            if previous_day is not None and day == previous_day:
                duplicate += 1
                raise ValueError(f'Duplicate store-product-date detected: {key}, {day}')
            if previous_day is not None and (day - previous_day).days == 1 and previous_out:
                acc['repeat_base'] += 1
                if any_so: acc['repeat_events'] += 1
            acc['observed_days'] += 1
            acc['stockout_days'] += int(any_so)
            acc['total_hours'] += hours
            acc['episodes'] += d['episodes'][i]
            acc['longest'] = max(acc['longest'], d['longest'][i])
            previous_day = day; previous_out = any_so
            sid = key[0]
            if sid not in store: store[sid] = [0, 0]
            store[sid][0] += 1; store[sid][1] += hours
            cat = d['first_category_id'][i]
            if cat not in category: category[cat] = [0, np.zeros(16, dtype=np.int64)]
            category[cat][0] += 1
            for h in range(16):
                if mask & (1 << h):
                    category[cat][1][h] += 1
                    hourly[h] += 1
    flush()
    conn.close()
    features = pd.DataFrame(summary)
    features.to_csv(OUT / 'RQ1_store_product_features.csv', index=False)
    stores = pd.DataFrame([
        {'store_id': k, 'observed_product_days': v[0],
         'stockout_hour_rate': v[1] / (16 * v[0])}
        for k,v in store.items()
    ]).sort_values('stockout_hour_rate', ascending=False)
    stores.to_csv(OUT / 'RQ1_store_summary.csv', index=False)
    print('Rows:', total_rows, '| Store-product pairs:', len(features), '| Stores:', len(stores))
    print('Overall operating-hour stockout rate:', round(sum(v[1] for v in store.values()) / (16 * total_rows), 4))
    print(features[['frequency','avg_episode_duration_hours','recurrence']].describe().round(3))

    # Descriptive patterns: frequency/duration median splits (not inferred clusters).
    valid = features[features.episode_count > 0].copy()
    fcut = valid.frequency.median(); dcut = valid.avg_episode_duration_hours.median()
    valid['pattern'] = np.select([
        (valid.frequency <= fcut) & (valid.avg_episode_duration_hours <= dcut),
        (valid.frequency <= fcut) & (valid.avg_episode_duration_hours > dcut),
        (valid.frequency > fcut) & (valid.avg_episode_duration_hours <= dcut),
        (valid.frequency > fcut) & (valid.avg_episode_duration_hours > dcut),
    ], ['Less frequent / Short', 'Less frequent / Long',
        'More frequent / Short', 'More frequent / Long'], default='Unclassified')
    features = features.merge(valid[['store_id','product_id','pattern']], on=['store_id','product_id'], how='left')
    features['pattern'] = features['pattern'].fillna('No stockouts')
    features.to_csv(OUT / 'RQ1_store_product_features.csv', index=False)
    pattern_summary = features.groupby('pattern', dropna=False).agg(
        combinations=('product_id','size'), mean_frequency=('frequency','mean'),
        mean_episode_duration=('avg_episode_duration_hours','mean'),
        mean_recurrence=('recurrence','mean'),
        median_observed_days=('observed_days','median')
    ).reset_index()
    pattern_summary.to_csv(OUT / 'RQ1_pattern_summary.csv', index=False)
    print('\nDescriptive pattern groups (median thresholds):')
    print(pattern_summary.to_string(index=False))

    sns.set_theme(style='whitegrid')
    fig, ax = plt.subplots(figsize=(9,6))
    sample = valid.sample(min(len(valid), 12000), random_state=42)
    sns.scatterplot(data=sample, x='frequency', y='avg_episode_duration_hours',
                    hue='pattern', alpha=.3, s=12, linewidth=0, ax=ax)
    ax.axvline(fcut, ls='--', color='gray'); ax.axhline(dcut, ls='--', color='gray')
    ax.set(title='RQ1: Frequency vs Episode Duration (sample of combinations)',
           xlabel='Share of observed days with stockout', ylabel='Mean within-day episode duration (hours)')
    fig.tight_layout(); fig.savefig(OUT / '01_frequency_vs_duration.png', dpi=160); plt.close(fig)

    fig, ax = plt.subplots(figsize=(9,5))
    sns.histplot(features.frequency, bins=30, ax=ax)
    ax.set(title='RQ1: Distribution of Stockout Frequency', xlabel='Share of observed days with stockout', ylabel='Store-product combinations')
    fig.tight_layout(); fig.savefig(OUT / '02_frequency_distribution.png', dpi=160); plt.close(fig)

    fig, ax = plt.subplots(figsize=(9,5))
    sns.histplot(features.recurrence.dropna(), bins=30, ax=ax)
    ax.set(title='RQ1: Next-day Stockout Recurrence', xlabel='P(stockout next calendar day | stockout today)', ylabel='Store-product combinations')
    fig.tight_layout(); fig.savefig(OUT / '03_recurrence_distribution.png', dpi=160); plt.close(fig)

    fig, ax = plt.subplots(figsize=(10,5))
    stores.head(10).plot.bar(x='store_id', y='stockout_hour_rate', ax=ax, legend=False)
    ax.set(title='Top 10 stores by observed operating-hour stockout rate', xlabel='Store', ylabel='Stockout hour rate')
    fig.tight_layout(); fig.savefig(OUT / '04_top_stores.png', dpi=160); plt.close(fig)

    cat_heat = pd.DataFrame({str(k): counts / n for k,(n,counts) in category.items()}, index=list(range(6,22))).T
    cat_heat.to_csv(OUT / 'RQ1_category_hourly_rates.csv')
    fig, ax = plt.subplots(figsize=(10, max(5, min(18, .28 * len(cat_heat)))))
    sns.heatmap(cat_heat, cmap='Reds', ax=ax)
    ax.set(title='Stockout rate by category and operating hour', xlabel='Hour of day', ylabel='Category ID')
    fig.tight_layout(); fig.savefig(OUT / '05_category_hour_heatmap.png', dpi=160); plt.close(fig)
    print('\nSaved all outputs to results/')
    print('IMPORTANT: episodes stop at 22:00; overnight continuation is not observed.')
    print('Recurrence is conditional on an observed consecutive calendar day.')

if __name__ == '__main__':
    if not TEMP.exists(): ingest()
    else: print('Reusing compact daily data:', TEMP)
    summarize()
